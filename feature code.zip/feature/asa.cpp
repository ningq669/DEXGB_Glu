#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<algorithm>
#include<iostream>
#include<string.h>
using namespace std;
bool map[50000];
double asa[50000];
int main()
{
	int i,j,k,l,m,n;
	char line[100];
	char str[10000];
	char name[100];
	char seq[50000];
	char sstr[10000];
	char sstr1[10000];
	FILE *p0=fopen("train.txt","r");
	//FILE *p=fopen("validation_label.txt","r");
	//FILE *p00=fopen("validation_line.txt","r");
	FILE *p1=fopen("asa_train80_positive.txt","w");
	FILE *p2=fopen("asa_train80_negative.txt","w");
	int num=0;
	while(fgets(sstr,10000,p0))
	{
		fgets(seq,10000,p0);
		fgets(str,50000,p0); 
		l=strlen(str);
		str[l-1]='\0';
		//printf("%s",seq);
		sprintf(name,"s%d.spd33",num++);
		FILE *p3=fopen(name,"r");
		fgets(sstr1,10000,p3);
		
		i=0;
		while(fgets(sstr1,10000,p3))
		{
			
			char *pp=strtok(sstr1," ");
			pp=strtok(NULL," ");
			pp=strtok(NULL," ");
			pp=strtok(NULL," ");
			asa[i]=atof(pp);
			
			i++;
		}
		//printf("%g",asa[0]);
		fclose(p3);
		n=l-1;
		for(i=0;i<n;i++)
		{
			if(str[i]=='1')
			{
				if(i<17)
				{
					for(j=i-17;j<0;j++)
					{
						fprintf(p1,"0 ");
					}
					for(j=0;j<=i+17;j++)
					{
						fprintf(p1,"%g ",asa[j]);
						
					}
				}
				else if(i+17>=n)
				{
					for(j=i-17;j<n;j++)
					{
						
						fprintf(p1,"%g ",asa[j]);
						
					}
					for(j=n;j<=i+17;j++)
					{
						
						fprintf(p1,"0 ");
						
					}
				}
				else
				{
					for(j=i-17;j<=i+17;j++)
					{
						
						fprintf(p1,"%g ",asa[j]);
						
					}
				}
				fprintf(p1,"\n");
			}
			else if(seq[i]=='K')
			{
				if(i<17)
				{
					for(j=i-17;j<0;j++)
					{
						fprintf(p2,"0 ");
					}
					for(j=0;j<=i+17;j++)
					{
						fprintf(p2,"%g ",asa[j]);
						
					}
				}
				else if(i+17>=n)
				{
					for(j=i-17;j<n;j++)
					{
						fprintf(p2,"%g ",asa[j]);
					}
					for(j=n;j<=i+17;j++)
					{
						fprintf(p2,"0 ");
						
					}
				}
				else
				{
					for(j=i-17;j<=i+17;j++)
					{
						fprintf(p2,"%g ",asa[j]);
					}
				}
				fprintf(p2,"\n");
			}
		}/**/
		if(num==80)break;
		//printf("%d\n",num);
	}
	
	return(0);
 }

