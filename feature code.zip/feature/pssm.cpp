#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<algorithm>
#include<iostream>
#include<string.h>
using namespace std;
bool map[50000];
int pssm[50000][25];
 
int main()
{
	int i,j,k,l,m,n;
	char line[100];
	char str[10000];
	char name[100];
	char seq[50000];
	char sstr[10000];
	char sstr1[10000];
	FILE *p0=fopen("test.txt","r");
	//FILE *p=fopen("validation_label.txt","r");
	//FILE *p00=fopen("validation_line.txt","r");
	FILE *p1=fopen("pssm_test_positive.txt","w");
	FILE *p2=fopen("pssm_test_negative.txt","w");
	int num=1;
	while(fgets(sstr,10000,p0))
	{
		fgets(seq,10000,p0);
		fgets(str,50000,p0); 
		l=strlen(str);
		str[l-1]='\0';
		
		sprintf(name,"%d.pssm",num++);
		FILE *p3=fopen(name,"r");
		fgets(sstr1,10000,p3);
		fgets(sstr1,10000,p3);
		fgets(sstr1,10000,p3);
		i=0;
		while(fgets(sstr1,10000,p3))
		{
			if(strlen(sstr1)<3)
				break;
			char *pp=strtok(sstr1," ");
			pp=strtok(NULL," ");
			for(j=0;j<20;j++)
			{
				pp=strtok(NULL," ");
				pssm[i][j]=atoi(pp);
			}
			i++;
		}
		fclose(p3);
		n=l-1;
		for(i=0;i<n;i++)
		{
			if(str[i]=='1')
			{
				if(i<17)//17��һ�봰�ڴ�С������Ը���ʵ������Լ����� 
				{
					for(j=i-17;j<0;j++)
					{
						for(k=0;k<20;k++)
						{
							fprintf(p1,"0 ");
						}
					}
					for(j=0;j<=i+17;j++)
					{
						for(k=0;k<20;k++)
						{
							fprintf(p1,"%d ",pssm[j][k]);
						}
						
					}
				}
				else if(i+17>=n)
				{
					for(j=i-17;j<n;j++)
					{
						for(k=0;k<20;k++)
						{
							fprintf(p1,"%d ",pssm[j][k]);
						}
					}
					for(j=n;j<=i+17;j++)
					{
						for(k=0;k<20;k++)
						{
							fprintf(p1,"0 ");
						}
					}
				}
				else
				{
					for(j=i-17;j<=i+17;j++)
					{
						for(k=0;k<20;k++)
						{
							fprintf(p1,"%d ",pssm[j][k]);
						}
					}
				}
				fprintf(p1,"\n");
			}
			else if(seq[i]=='K')
			{
				if(i<17)
				{
					for(j=i-17;j<0;j++)
					{
						for(k=0;k<20;k++)
						{
							fprintf(p2,"0 ");
						}
					}
					for(j=0;j<=i+17;j++)
					{
						for(k=0;k<20;k++)
						{
							fprintf(p2,"%d ",pssm[j][k]);
						}
						
					}
				}
				else if(i+17>=n)
				{
					for(j=i-17;j<n;j++)
					{
						for(k=0;k<20;k++)
						{
							fprintf(p2,"%d ",pssm[j][k]);
						}
					}
					for(j=n;j<=i+17;j++)
					{
						for(k=0;k<20;k++)
						{
							fprintf(p2,"0 ");
						}
					}
				}
				else
				{
					for(j=i-17;j<=i+17;j++)
					{
						for(k=0;k<20;k++)
						{
							fprintf(p2,"%d ",pssm[j][k]);
						}
					}
				}
				fprintf(p2,"\n");
			}
		}
		//printf("%d\n",num);
	}
	
	return(0);
 }

