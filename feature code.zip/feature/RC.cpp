#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<algorithm>
#include<iostream>
#include<string.h>
using namespace std;

int main()
{
	int i,j,k,l,m,n;
	char str[10000];
	char amino[30]="ARNDCQEGHILKMFPSTWYV*";
	int count[30];
	FILE *p=fopen("train_negative.txt","r");
	
	freopen("train_RC_negative.txt","w",stdout);
	m=0;
	//n=0;
	
	while(fgets(str,1000,p))
	{
		memset(count,0,sizeof(count));
		l=strlen(str);
		for(i=0;i<l-1;i++)
		{
			if(i==17)continue;
			for(j=0;j<20;j++)
			{
				if(str[i]==amino[j])
				{
					count[j]++;
					break;
				}
			}
		}
		for(i=0;i<20;i++)
		{
			printf("%g ",count[i]*1.0/l);
		 } 
		printf("\n");
	 } 
	
	return(0);
 }

